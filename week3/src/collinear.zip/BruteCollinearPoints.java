import java.util.ArrayList;
import java.util.Arrays;

public class BruteCollinearPoints {
    private LineSegment[] segments;
    private ArrayList<LineSegment> found;


    // finds all line segments containing 4 points
    public BruteCollinearPoints(Point[] points){
        if (points == null)
            throw new IllegalArgumentException("The input is null.");

        checkDuplicated(points);
        checkDuplicated(points);

        int N = points.length;

        for (int p = 0; p < N - 3; p++) {
            for (int q = p+1; q < N - 2; q++) {
                double slopepq = points[p].slopeTo(points[q]);
                for (int r = q+1; r < N - 1; r++) {
                    double slopepr = points[p].slopeTo(points[r]);
                    for (int s = r+1; s < N; s++) {
                        double slopeps = points[p].slopeTo(points[s]);
                        if (slopepq == slopepr && slopepq == slopeps) {
                            found.add(new LineSegment(points[p], points[s]));
                        }
                    }
                }
            }
        }

        segments = found.toArray(new LineSegment[found.size()]);


    }

    // the number of line segments
    public int numberOfSegments() {

        return segments.length;

    }

    // the line segments
    public LineSegment[] segments() {

        return segments;
    }

    private void checkDuplicated(Point[] points) {
        for (int i = 0; i < points.length - 1; i++) {
            if (points[i].compareTo(points[i+1]) == 0) {
                throw new IllegalArgumentException("Duplicated Entries!");
            }
        }
    }

    private void checkNull(Point[] points) {
        for (int i = 0; i < points.length - 1; i++) {
            if (points[i] == null) {
                throw new IllegalArgumentException("Null points in the input.");
            }
        }
    }

}
